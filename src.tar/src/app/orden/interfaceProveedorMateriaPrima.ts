export interface proveedorMateriaPrima {
    id?:number;
    materia_prima: number;
    materia_prima_descripcion:'';
    proveedor: number;
    proveedor_nombre:'';
    precio: number;
}