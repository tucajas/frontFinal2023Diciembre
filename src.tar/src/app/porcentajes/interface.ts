export interface Descuento {
    id?: string;
    titulo: string;
    desc: number;

}