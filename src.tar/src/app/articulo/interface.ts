export interface Articulo {
    id?:            number;
    descripcion:    string;
    stock:          number;
    precioCosto:    number;
    precioVenta:    number;

}