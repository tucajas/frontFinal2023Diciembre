export interface Proveedor{
    id?:number;
    nombre:String;
    direccion:String;
    telefono:String;
}