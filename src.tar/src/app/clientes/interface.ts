export interface Cliente{
    id?: number;
    nombre: string;
    apellido: string;
    direccion: string;
    telefono: string;
    cuenta_Corriente:string;
}