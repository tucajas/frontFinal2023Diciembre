export interface TipoTrabajo {
    id?:number;
    descripcion: string;
    precio:number;

}