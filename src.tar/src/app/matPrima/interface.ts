export interface matPrima {
    id:number;
    descripcion:'';
}