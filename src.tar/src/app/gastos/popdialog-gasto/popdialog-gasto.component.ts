import { Component } from '@angular/core';

@Component({
  selector: 'app-popdialog-gasto',
  templateUrl: './popdialog-gasto.component.html',
  styleUrls: ['./popdialog-gasto.component.css']
})
export class PopdialogGastoComponent {

}
