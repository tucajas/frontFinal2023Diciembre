export interface Gastos{

    id?: number;
    fecha:String;
    materiaprima :String;
    proveedor: String;
    cantidadCompra: number;
    valorCompra: number;
    valorAbonadoCC:number;
    valorAbonadoFt: number;
    saldo:number;

}


